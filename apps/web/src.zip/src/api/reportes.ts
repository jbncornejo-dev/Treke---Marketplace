// apps/web/src/api/reports.ts
import { api } from "./client";

/* ====== TIPOS SEGÚN LO QUE DEVUELVE getAdminDashboard() ====== */

export interface AdminIngresosTotal {
  compras_ok: number | null;
  bs_total: string | number | null;
  creditos_total: string | number | null;
}

export interface AdminIngresosMes {
  periodo: string; // ISO (primer día del mes)
  compras_ok: number | null;
  bs_total: string | number | null;
  creditos_total: string | number | null;
}

export interface AdminImpactoTotal {
  co2: string | number | null;
  energia: string | number | null;
  agua: string | number | null;
  residuos: string | number | null;
  creditos: string | number | null;
}

export interface AdminConsumoVsGeneracion {
  origen: "compra_directa" | "generado_intercambios" | "gastado_intercambios" | "otros" | string;
  total: string | number;
}

export interface AdminSuscripciones {
  total_registros: number;
  activas: number;
  usuarios_con_suscripcion: number;
  ratio_activas: string | number | null;
}

export interface AdminTotalIntercambios {
  completados: number;
  activos: number;
  total: number;
}

/** Shape EXACTO de lo que devuelve getAdminDashboard() en el backend */
export interface AdminOverview {
  ingresos_total: AdminIngresosTotal | null;
  ingresos_por_mes: AdminIngresosMes[];
  impacto_total: AdminImpactoTotal | null;
  adopcion_suscripcion: AdminSuscripciones | null;
  total_intercambios: AdminTotalIntercambios | null;
  consumo_vs_generacion: AdminConsumoVsGeneracion[];
}

/** Categorías (vw_intercambios_por_categorias) */
export interface AdminTopCategoriaItem {
  categoria_id: number;
  categoria: string;
  intercambios: number;
}

/** Usuarios top (vw_ranking_participacion + ROW_NUMBER) */
export interface AdminTopUsuarioItem {
  usuario_id: number;
  email: string;
  intercambios: number;
  compras_creditos: number;
  creditos_comprados: number;
  tiene_suscripcion: boolean;
  puntaje: number;
  pos?: number;
}

/* ====== WRAPPERS ====== */

export const adminOverview = async (): Promise<AdminOverview> => {
  const resp = await api.get<{ ok: boolean; data: AdminOverview }>(
    `/api/report/admin/overview`
  );
  const payload = (resp as any).data ?? (resp as any); // axios .data o custom
  return (payload as any).data ?? payload;
};

export const adminTopCategorias = async (): Promise<AdminTopCategoriaItem[]> => {
  const resp = await api.get<{ ok: boolean; data: AdminTopCategoriaItem[] }>(
    `/api/report/admin/top-categorias`
  );
  const payload = (resp as any).data ?? (resp as any);
  return (payload as any).data ?? payload;
};

export const adminTopUsuarios = async (): Promise<AdminTopUsuarioItem[]> => {
  const resp = await api.get<{ ok: boolean; data: AdminTopUsuarioItem[] }>(
    `/api/report/admin/top-usuarios`
  );
  const payload = (resp as any).data ?? (resp as any);
  return (payload as any).data ?? payload;
};
