// api/reportes.usuario.ts
import { api } from "./client";
import { getCurrentUser } from "./auth";

/** Helper: obtiene el id del usuario logueado.
 *  - Primero usa getCurrentUser() (treke_user de localStorage)
 *  - Si no hay nada, intenta algunos fallback suaves.
 *  - Nunca lanza error, puede devolver null.
 */
const getUsuarioId = (): number | null => {
  const current = getCurrentUser();
  if (current && typeof current.id === "number" && current.id > 0) {
    return current.id;
  }

  // Fallbacks suaves, por si cambias el storage en el futuro
  const rawId =
    localStorage.getItem("treke_user_id") ||
    localStorage.getItem("user_id") ||
    null;
  if (rawId) {
    const n = Number(rawId);
    if (Number.isFinite(n) && n > 0) return n;
  }

  const rawUser =
    localStorage.getItem("treke_user") ||
    localStorage.getItem("user") ||
    null;
  if (rawUser) {
    try {
      const u = JSON.parse(rawUser);
      const possibleId = u?.id ?? u?.usuario?.id ?? u?.user?.id;
      const n = Number(possibleId);
      if (Number.isFinite(n) && n > 0) return n;
    } catch {
      // ignoramos
    }
  }

  return null;
};

/* ========= TIPOS ========= */

/**
 * NUEVO shape de /api/report/user/me/summary
 * viene de S.getUserSummary(uid):
 * {
 *   actividad,
 *   ranking,
 *   saldo,
 *   compras
 * }
 */
export interface UserSummary {
  actividad: {
    usuario_id: number;
    email: string;
    ultima_actividad: string; // ISO
  } | null;

  ranking: {
    usuario_id: number;
    email: string;
    intercambios: number;
    compras_creditos: number;
    creditos_comprados: number;
    tiene_suscripcion: boolean;
    puntaje: number;
    rank_intercambios: number;
  } | null;

  saldo: {
    usuario_id: number;
    saldo_disponible: string | number;
    saldo_retenido: string | number;
    saldo_total: string | number;
  } | null;

  compras: {
    usuario_id: number;
    compras_ok: number;
    bs_total: string | number | null;
    creditos_total: string | number | null;
  } | null;
}

/**
 * NUEVO shape de /api/report/user/me/ranking
 * controller devuelve: { ok: true, data: { me, top10 } }
 *  - me: fila de rankingMeWithPosition (vw_ranking_participacion + ROW_NUMBER)
 *  - top10: filas de rankingTop10WithNombre
 */
export interface UserRankingResponse {
  me: {
    usuario_id: number;
    email: string;
    intercambios: number;
    compras_creditos: number;
    creditos_comprados: number;
    tiene_suscripcion: boolean;
    puntaje: number;
    rank_intercambios: number;
  } | null;
  top10: Array<{
    usuario_id: number;
    intercambios_hechos: number;
    rank_intercambios: number;
    nombre: string;
  }>;
}

/** Historial de usuario (de momento el endpoint está 501 en el backend) */
export interface UserHistoryItem {
  intercambio_id: number;
  comprador_id: number;
  vendedor_id: number;
  fecha_completado: string | null;
  fecha_de_aceptacion: string;
  monto_credito: number;
  rol: "compra" | "venta" | null;
  // campos extra opcionales
  estado?: string;
  publicacion_titulo?: string;
  categoria_nombre?: string;
}

/** Ventas por mes (ahora usa los datos de monetización por mes) */
export interface OrgVentaItem {
  periodo: string; // ISO (primer día del mes)
  compras_ok: number;
  bs_total: string | number | null;
  creditos_total: string | number | null;
}

/** Wallet de la org/emprendedor: saldo actual */
export interface OrgWalletItem {
  usuario_id: number;
  saldo_disponible: string | number;
  saldo_retenido: string | number;
  saldo_total: string | number;
}

/** Categorías más demandadas para la org (vw_intercambios_por_categorias) */
export interface OrgTopCategoriaItem {
  categoria_id: number;
  categoria: string;
  intercambios: number;
}

/* ========= ENDPOINTS USER ========= */

export const getUserSummary = async (): Promise<UserSummary> => {
  const uid = getUsuarioId();
  const url = uid
    ? `/api/report/user/me/summary?usuario_id=${uid}`
    : `/api/report/user/me/summary`;

  const resp = await api.get<{ ok: boolean; data: UserSummary }>(url);
  // axios: resp.data = { ok, data }
  const payload = (resp as any).data ?? (resp as any);
  return (payload as any).data ?? payload;
};

export const getUserRanking = async (): Promise<UserRankingResponse> => {
  const uid = getUsuarioId();
  const url = uid
    ? `/api/report/user/me/ranking?usuario_id=${uid}`
    : `/api/report/user/me/ranking`;

  const resp = await api.get<{ ok: boolean; data: UserRankingResponse }>(url);
  const payload = (resp as any).data ?? (resp as any);
  return (payload as any).data ?? payload;
};

/**
 * OJO: en el backend actual /report/user/me/history devuelve 501 (no implementado),
 * así que aquí devolvemos [] si el server responde error.
 */
export const getUserHistory = async (): Promise<UserHistoryItem[]> => {
  const uid = getUsuarioId();
  const url = uid
    ? `/api/report/user/me/history?usuario_id=${uid}`
    : `/api/report/user/me/history`;

  try {
    const resp = await api.get<{ ok: boolean; data: UserHistoryItem[] }>(url);
    const payload = (resp as any).data ?? (resp as any);
    if (payload && payload.ok === false && Array.isArray(payload.data) === false) {
      // por si el backend devuelve { ok:false, error: '...' }
      return [];
    }
    return (payload as any).data ?? payload;
  } catch {
    return [];
  }
};

/* ========= ENDPOINTS ORG / EMPRENDEDOR ========= */

/**
 * /api/report/org/me/ventas
 * → ahora devuelve los mismos datos que vw_monetizacion_ingresos_por_mes
 */
export const getOrgVentas = async (): Promise<OrgVentaItem[]> => {
  const uid = getUsuarioId();
  const url = uid
    ? `/api/report/org/me/ventas?usuario_id=${uid}`
    : `/api/report/org/me/ventas`;

  const resp = await api.get<{ ok: boolean; data: OrgVentaItem[] }>(url);
  const payload = (resp as any).data ?? (resp as any);
  return (payload as any).data ?? payload;
};

/**
 * /api/report/org/me/wallet
 * → devuelve una sola fila de vw_saldo_creditos_usuario para ese usuario
 */
export const getOrgWallet = async (): Promise<OrgWalletItem | null> => {
  const uid = getUsuarioId();
  const url = uid
    ? `/api/report/org/me/wallet?usuario_id=${uid}`
    : `/api/report/org/me/wallet`;

  const resp = await api.get<{ ok: boolean; data: OrgWalletItem | null }>(url);
  const payload = (resp as any).data ?? (resp as any);
  return (payload as any).data ?? payload;
};

export const getOrgTopCategorias = async (): Promise<OrgTopCategoriaItem[]> => {
  const resp = await api.get<{ ok: boolean; data: OrgTopCategoriaItem[] }>(
    `/api/report/org/me/top-categorias`
  );
  const payload = (resp as any).data ?? (resp as any);
  return (payload as any).data ?? payload;
};
