import { useState } from "react";

export type LoginValues = { email: string; password: string };

export default function Login({
  onSubmit,
}: {
  // Si conectas backend, pásame esta función. Debe lanzar error en fallo.
  onSubmit?: (values: LoginValues) => Promise<void> | void;
}) {
  const [values, setValues] = useState<LoginValues>({
    email: "",
    password: "",
  });
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<{ type: "ok" | "err"; text: string } | null>(
    null
  );

  const canSend =
    values.email.includes("@") && values.password.trim().length >= 1;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!canSend || loading) return;
    setLoading(true);
    setMsg(null);
    try {
      if (onSubmit) {
        await onSubmit(values);
      } else {
        // Modo demo sin backend:
        await new Promise((r) => setTimeout(r, 600));
      }
      setMsg({ type: "ok", text: "Sesión iniciada." });
    } catch (err: any) {
      setMsg({
        type: "err",
        text: err?.message || "Email o contraseña inválidos",
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="w-full rounded-2xl border border-neutral-800 bg-neutral-950 p-5 shadow-[0_0_0_1px_rgba(255,255,255,0.02),0_8px_30px_rgba(0,0,0,0.25)]"
    >
      <h2 className="text-lg md:text-xl font-semibold mb-4">Login</h2>

      <div className="space-y-3">
        <label className="block space-y-1.5">
          <span className="text-sm text-neutral-300">Email</span>
          <input
            type="email"
            placeholder="demo@treke.dev"
            value={values.email}
            onChange={(e) => setValues((s) => ({ ...s, email: e.target.value }))}
            className="w-full rounded-xl bg-neutral-900/60 border border-neutral-800 px-3 py-2 text-sm text-neutral-100 placeholder:text-neutral-500 focus:outline-none focus:ring-2 focus:ring-green-600"
          />
        </label>

        <label className="block space-y-1.5">
          <span className="text-sm text-neutral-300">Contraseña</span>
          <input
            type="password"
            placeholder="••••••••"
            value={values.password}
            onChange={(e) =>
              setValues((s) => ({ ...s, password: e.target.value }))
            }
            className="w-full rounded-xl bg-neutral-900/60 border border-neutral-800 px-3 py-2 text-sm text-neutral-100 placeholder:text-neutral-500 focus:outline-none focus:ring-2 focus:ring-green-600"
          />
        </label>

        <button
          disabled={!canSend || loading}
          className="inline-flex w-full items-center justify-center rounded-xl border border-neutral-800 px-4 py-2 text-sm text-neutral-200 hover:bg-neutral-900 focus:outline-none focus:ring-2 focus:ring-green-600 disabled:opacity-60 disabled:cursor-not-allowed"
        >
          {loading ? "Entrando…" : "Entrar"}
        </button>

        {msg && (
          <p
            className={
              "text-sm " +
              (msg.type === "ok" ? "text-green-400" : "text-red-400")
            }
          >
            {msg.text}
          </p>
        )}
      </div>
    </form>
  );
}
