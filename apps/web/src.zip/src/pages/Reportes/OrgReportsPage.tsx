// apps/web/src/pages/reports/OrgReportsPage.tsx

import React, { useEffect, useState } from "react";
import {
  getOrgVentas,
  getOrgWallet,
  getOrgTopCategorias,
} from "../../api/reportes.usuario";
import type {
  OrgVentaItem,
  OrgWalletItem,
  OrgTopCategoriaItem,
} from "../../api/reportes.usuario";

const OrgReportsPage: React.FC = () => {
  const [ventas, setVentas] = useState<OrgVentaItem[]>([]);
  const [wallet, setWallet] = useState<OrgWalletItem | null>(null);
  const [topCategorias, setTopCategorias] = useState<OrgTopCategoriaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        setError(null);
        const [_ventas, _wallet, _topCat] = await Promise.all([
          getOrgVentas(),
          getOrgWallet(),
          getOrgTopCategorias(),
        ]);
        setVentas(_ventas);
        setWallet(_wallet);
        setTopCategorias(_topCat);
      } catch (err: any) {
        console.error(err);
        setError(err.message ?? "Error cargando reportes de organización");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) return <div className="p-4">Cargando reportes...</div>;
  if (error) return <div className="p-4 text-red-600">Error: {error}</div>;

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 space-y-6">
      <h1 className="text-2xl font-bold mb-2">Reportes de mi organización</h1>

      {/* Ventas por mes (basado en vw_monetizacion_ingresos_por_mes) */}
      <section className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-sm p-4">
        <h2 className="text-xl font-semibold mb-2">Ventas por mes</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm border border-neutral-200 dark:border-neutral-800 rounded-lg overflow-hidden">
            <thead className="bg-neutral-100 dark:bg-neutral-900/60">
              <tr>
                <th className="px-3 py-2 border-b border-neutral-200 dark:border-neutral-800 text-xs font-semibold uppercase tracking-wide text-neutral-600 dark:text-neutral-300">
                  Mes
                </th>
                <th className="px-3 py-2 border-b border-neutral-200 dark:border-neutral-800 text-xs font-semibold uppercase tracking-wide text-neutral-600 dark:text-neutral-300">
                  Créditos vendidos
                </th>
                <th className="px-3 py-2 border-b border-neutral-200 dark:border-neutral-800 text-xs font-semibold uppercase tracking-wide text-neutral-600 dark:text-neutral-300">
                  Compras completadas
                </th>
              </tr>
            </thead>
            <tbody>
              {ventas.length ? (
                ventas.map((v, i) => (
                  <tr
                    key={i}
                    className="odd:bg-white even:bg-neutral-50 dark:odd:bg-neutral-900 dark:even:bg-neutral-950"
                  >
                    <td className="px-3 py-1 border-b border-neutral-200 dark:border-neutral-800">
                      {new Date(v.periodo).toLocaleDateString("es-BO", {
                        year: "numeric",
                        month: "short",
                      })}
                    </td>
                    <td className="px-3 py-1 border-b border-neutral-200 dark:border-neutral-800">
                      {v.creditos_total ?? 0}
                    </td>
                    <td className="px-3 py-1 border-b border-neutral-200 dark:border-neutral-800">
                      {v.compras_ok ?? 0}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td className="px-3 py-2" colSpan={3}>
                    Sin ventas aún.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Saldo actual de billetera */}
      <section className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-sm p-4">
        <h2 className="text-xl font-semibold mb-2">Saldo de billetera</h2>
        {wallet ? (
          <div className="grid md:grid-cols-3 gap-4">
            <KpiCard
              title="Saldo disponible"
              value={wallet.saldo_disponible ?? 0}
            />
            <KpiCard
              title="Saldo retenido"
              value={wallet.saldo_retenido ?? 0}
            />
            <KpiCard title="Saldo total" value={wallet.saldo_total ?? 0} />
          </div>
        ) : (
          <p className="text-sm text-neutral-500">
            Aún no tienes billetera o saldo registrado.
          </p>
        )}
      </section>

      {/* Top categorías */}
      <section className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-sm p-4 mb-6">
        <h2 className="text-xl font-semibold mb-2">
          Categorías con más intercambios
        </h2>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm border border-neutral-200 dark:border-neutral-800 rounded-lg overflow-hidden">
            <thead className="bg-neutral-100 dark:bg-neutral-900/60">
              <tr>
                <th className="px-3 py-2 border-b border-neutral-200 dark:border-neutral-800 text-xs font-semibold uppercase tracking-wide text-neutral-600 dark:text-neutral-300">
                  Categoría
                </th>
                <th className="px-3 py-2 border-b border-neutral-200 dark:border-neutral-800 text-xs font-semibold uppercase tracking-wide text-neutral-600 dark:text-neutral-300">
                  Intercambios completados
                </th>
              </tr>
            </thead>
            <tbody>
              {topCategorias.length ? (
                topCategorias.map((c) => (
                  <tr
                    key={c.categoria_id}
                    className="odd:bg-white even:bg-neutral-50 dark:odd:bg-neutral-900 dark:even:bg-neutral-950"
                  >
                    <td className="px-3 py-1 border-b border-neutral-200 dark:border-neutral-800">
                      {c.categoria}
                    </td>
                    <td className="px-3 py-1 border-b border-neutral-200 dark:border-neutral-800">
                      {c.intercambios}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td className="px-3 py-2" colSpan={2}>
                    Aún no hay intercambios.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

type KpiCardProps = { title: string; value: string | number | null };

const KpiCard: React.FC<KpiCardProps> = ({ title, value }) => (
  <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-sm p-4">
    <div className="text-xs font-medium text-neutral-500 dark:text-neutral-400">
      {title}
    </div>
    <div className="text-2xl font-semibold mt-1">
      {typeof value === "number" ? value.toLocaleString("es-BO") : value ?? 0}
    </div>
  </div>
);

export default OrgReportsPage;
